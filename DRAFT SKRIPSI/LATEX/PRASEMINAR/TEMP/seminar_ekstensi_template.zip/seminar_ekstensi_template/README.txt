Template makalah seminar
   File utama : seminar_ekstensi.tex
   File yang harus diedit adalah:
    (1) seminar_information.tex -- identitas makalah seminar
    (2) abstrak.tex
    (3) pendahuluan.tex
    (4) metode.tex
    (5) hasil.tex
    (6) kesimpulan.tex
    (7) daftar_pustaka.tex
    (8) lampiran.tex
    
